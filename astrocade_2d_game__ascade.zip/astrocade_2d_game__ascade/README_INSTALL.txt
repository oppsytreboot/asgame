1) Unzip this package into a folder.
2) Locate your astrocade_2d_game_ installation folder. Common locations:
   - Windows: C:\Program Files\astrocade_2d_game_ or C:\Program Files (x86)\astrocade_2d_game_
   - Steam: \SteamLibrary\steamapps\common\astrocade_2d_game_
   - macOS: /Applications/astrocade_2d_game_.app/Contents/Resources/
3) For mod type "plugin":
   - Plugins are typically binary libraries. On Windows place the .dll into the game's "plugins" or main executable folder; on Linux use the .so equivalent in the game's library/plugin directory. Backup originals first.
4) Launch the game. If problems occur, restore backups.

DISCLAIMER: This tool packages files and creates simple instructions. Some games use signed assets or anti-cheat; modifying or injecting files can break the game or violate terms of service. Use at your own risk.