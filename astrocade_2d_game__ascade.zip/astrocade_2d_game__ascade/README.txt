Mod: ascade
Game: astrocade_2d_game_
Type: plugin

Description:
astrocade game 

Install: See README_INSTALL.txt