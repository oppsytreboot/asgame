export const BLOOKS = [
  { name: 'Chick', rarity: 'Common', image: '/assets/blooks/chick.png' },
  { name: 'Chicken', rarity: 'Common', image: '/assets/blooks/chicken.png' },
  { name: 'Cow', rarity: 'Common', image: '/assets/blooks/cow.png' },
  { name: 'Pig', rarity: 'Common', image: '/assets/blooks/pig.png' },
  { name: 'Sheep', rarity: 'Common', image: '/assets/blooks/sheep.png' },
  { name: 'Dog', rarity: 'Uncommon', image: '/assets/blooks/dog.png' },
  { name: 'Cat', rarity: 'Uncommon', image: '/assets/blooks/cat.png' },
  { name: 'Owl', rarity: 'Rare', image: '/assets/blooks/owl.png' },
  { name: 'Dragon', rarity: 'Epic', image: '/assets/blooks/dragon.png' },
  { name: 'King', rarity: 'Legendary', image: '/assets/blooks/king.png' },
  { name: 'Megalodon', rarity: 'Legendary', image: '/assets/blooks/megalodon.png' },
  { name: 'Spaceman', rarity: 'Chroma', image: '/assets/blooks/spaceman.png' },
  { name: 'Mysterious Goblin', rarity: 'Mystical', image: '/assets/blooks/goblin.png' }
];