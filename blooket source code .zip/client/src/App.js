import React, { useState } from 'react';
import { BLOOKS } from './data/blooks';

function App() {
  return (
    <div className="app-container">
      <header>
        <h1>Blooket Clone</h1>
      </header>
      <main>
        <section className="blook-gallery">
          {BLOOKS.map(blook => (
            <div key={blook.name} className={`blook-card ${blook.rarity.toLowerCase()}`}>
              <img src={blook.image} alt={blook.name} />
              <p>{blook.name}</p>
              <span className="rarity-tag">{blook.rarity}</span>
            </div>
          ))}
        </section>
      </main>
    </div>
  );
}

export default App;