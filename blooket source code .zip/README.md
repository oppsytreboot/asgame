# Blooket Clone Full Stack

This is a full-featured Blooket clone project structure including a Node.js backend with Socket.io and a React frontend.

## Structure
- `/server`: Node.js/Express socket server for real-time multiplayer.
- `/client/src/data`: Contains the full database of Blooks and their rarities.
- `/client/public/assets`: Visual assets for the game.

## Installation
1. Run `npm install` in the root directory.
2. Navigate to `server/` and run `npm start`.
3. Navigate to `client/` and run `npm start`.

## Customization
To add new Blooks, update `client/src/data/blooks.js` and add the corresponding `.png` file to the assets folder.

## Features
- Real-time Lobby
- Blook Selection
- Rarity tiers (Common to Mystical)
- CSS Animation for Chroma Blooks