const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

const games = {};

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  socket.on('create_game', (gameId) => {
    games[gameId] = { players: [], state: 'lobby' };
    socket.join(gameId);
    console.log(`Game created: ${gameId}`);
  });

  socket.on('join_game', ({ gameId, username, blook }) => {
    if (games[gameId]) {
      const player = { id: socket.id, username, blook, score: 0 };
      games[gameId].players.push(player);
      socket.join(gameId);
      io.to(gameId).emit('update_players', games[gameId].players);
    }
  });

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));